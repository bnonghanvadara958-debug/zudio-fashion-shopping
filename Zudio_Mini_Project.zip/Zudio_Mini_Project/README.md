# Zudio Fashion Shopping Website — Mini Project

A responsive front-end fashion shopping demo built with HTML, CSS and JavaScript.

## Run the project
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Firefox or Edge.
3. Try the category filters, search, wishlist hearts, add-to-bag/cart, demo sign-in and newsletter form.

## Files
- `index.html` — page structure
- `style.css` — responsive styling
- `script.js` — interactive demo features

## Important
This is a front-end demonstration project. It does not connect to a real inventory, user database, payment gateway or official Zudio service. The project is an independent student demo and is not affiliated with Zudio. Replace or verify branding/assets as required by your instructor before submission.
