const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const overlay = $('#overlay');
const panels = ['#drawer','#cartPanel','#accountModal','#searchModal'];
function openPanel(selector){panels.forEach(p=>$(p).classList.remove('show'));$(selector).classList.add('show');overlay.classList.add('show')}
function closePanels(){panels.forEach(p=>$(p).classList.remove('show'));overlay.classList.remove('show')}
$('#menuBtn').addEventListener('click',()=>openPanel('#drawer'));
$('#cartBtn').addEventListener('click',()=>openPanel('#cartPanel'));
$('#accountBtn').addEventListener('click',()=>openPanel('#accountModal'));
$('#searchBtn').addEventListener('click',()=>openPanel('#searchModal'));
overlay.addEventListener('click',closePanels);
$$('[data-close]').forEach(b=>b.addEventListener('click',closePanels));
$$('.drawer a').forEach(a=>a.addEventListener('click',closePanels));

let cart=[];
function renderCart(){
  $('#cartCount').textContent=cart.reduce((n,x)=>n+x.qty,0);
  $('#bagItems').textContent=`(${cart.reduce((n,x)=>n+x.qty,0)})`;
  $('#cartTotal').textContent='₹'+cart.reduce((n,x)=>n+x.price*x.qty,0);
  $('#cartItems').innerHTML=cart.length?cart.map((x,i)=>`<div class="cart-item"><span>${x.name}<br>₹${x.price} × ${x.qty}</span><button class="remove" data-remove="${i}">REMOVE</button></div>`).join(''):'<p class="empty">Your bag is waiting for something lovely.</p>';
  $$('[data-remove]').forEach(b=>b.addEventListener('click',()=>{cart.splice(+b.dataset.remove,1);renderCart()}));
}
$$('.add-btn').forEach(b=>b.addEventListener('click',()=>{const item=cart.find(x=>x.name===b.dataset.name);item?item.qty++:cart.push({name:b.dataset.name,price:+b.dataset.price,qty:1});renderCart();b.textContent='ADDED ✓';setTimeout(()=>b.textContent='ADD TO BAG +',1000)}));
$('#checkoutBtn').addEventListener('click',()=>{$('#checkoutMessage').textContent=cart.length?'Demo checkout: your items are ready. No payment is collected.':'Your bag is empty.'});
$$('.filter').forEach(b=>b.addEventListener('click',()=>{$$('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');$$('.product').forEach(p=>p.style.display=b.dataset.filter==='all'||p.dataset.category===b.dataset.filter?'block':'none')}));
$$('.heart').forEach(b=>b.addEventListener('click',()=>{b.textContent=b.textContent==='♡'?'♥':'♡';b.style.color=b.textContent==='♥'?'#f15a36':''}));
$('#newsletterForm').addEventListener('submit',e=>{e.preventDefault();$('#newsletterMessage').textContent='Thanks for subscribing! (Demo form)';e.target.reset()});
$('#loginForm').addEventListener('submit',e=>{e.preventDefault();$('#loginMessage').textContent='Demo sign-in validated. No account was created.'});
$('#searchInput').addEventListener('input',e=>{const q=e.target.value.toLowerCase();let count=0;$$('.product').forEach(p=>{const match=p.textContent.toLowerCase().includes(q);p.style.display=match?'block':'none';if(match)count++});$('#searchMessage').textContent=q?`${count} matching product(s) in this collection.`:''});
